﻿█████████████████████████████
█
█   警告⚠️：本文件为开发预览版，请勿用于生产环境！
█   使用方法： 
█       将本压缩包内所有文件解压到plugins文件夹下即可
█
█████████████████████████████
█
█   当前插件版本：v0.1.2246
█   最低版本要求：
█       Bedrock Dedicated Server: 1.20.30
█       LiteLoader: 2.16.1
█       LiteLoader.NET: 2.16.1
█
█████████████████████████████
█
█   > .Net 7.0 运行库 <
█       https://dotnet.microsoft.com/zh-cn/download/dotnet/thank-you/runtime-7.0.0-windows-x64-installer
█   > 安装文档[必读] <
█      https://d.mcpf.live/installation/
█
█████████████████████████████
█
█   构建时间：2023年09月30日 15:19:49
█   构建系统：Linux 3.10.0-1160.53.1.el7.x86_64 #1 SMP Fri Jan 14 13:59:45 UTC 2022
█   LiteLoader.NET仓库：https://github.com/LiteLDev/LiteLoader.NET
█
█████████████████████████████
█
█   Telegram Group：https://t.me/joinchat/TDe2w1ZgMVSw10vbugwg1w
█   QQ群：850092152
█   如有bug可前往反馈
█
█████████████████████████████
█
█  测试版下载地址(密码:114514)：
█      https://gxh.lanzoum.com/b03v3gxbi 
█  使用文档：
█      https://d.mcpf.live/usage/
█  API对接文档（支持JS、C++、C#、VB、F#）：
█      https://d.mcpf.live/api/
█
█████████████████████████████